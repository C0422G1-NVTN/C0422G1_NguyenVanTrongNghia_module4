package service.impl;

import bean.Student;
import repository.IStudentRepository;
import repository.impl.StudentRepository;
import service.IStudentService;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentService implements IStudentService {

    // DI
    private IStudentRepository iStudentRepository = new StudentRepository();

    @Override
    public List<Student> findAll() {
        return this.iStudentRepository.findAll();
    }

    @Override
    public Student findById(Integer id) {
        return null;
    }

    @Override
    public Map<String, String> save(Student student) {
        // 1. Validate thong tin hoc vien: regex, if, else
        // => Neu du lieu hop le thi goi Repository => save()
        // => Neu khong thi tra loi ve cho Servlet

        Map<String, String> mapErrors = new HashMap<>();

        if (!student.getName().isEmpty()) {
            if (!student.getName().matches("[A-Za-z ]+")) {
                mapErrors.put("name", "Please input right format!");
            }
        } else {
            mapErrors.put("name", "Please input name!");
        }

        if (mapErrors.size() == 0) {
            this.iStudentRepository.save(student);
        }

        return mapErrors;
    }
}
