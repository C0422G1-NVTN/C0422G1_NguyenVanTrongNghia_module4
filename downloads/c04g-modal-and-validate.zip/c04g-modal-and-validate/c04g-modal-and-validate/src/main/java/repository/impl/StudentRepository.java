package repository.impl;

import bean.Student;
import repository.IStudentRepository;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentRepository implements IStudentRepository {

    @Override
    public List<Student> findAll() {
        List<Student> studentList = new ArrayList<>();

        try {
            Statement statement = BaseRepository.connection.createStatement();
            ResultSet resultSet = statement.executeQuery(
                    "select id, `name`, date_of_birth\n" +
                    "from student");

            Student studentObj = null;

            while(resultSet.next()) {
                studentObj = new Student();
                studentObj.setId(resultSet.getInt("id"));
                studentObj.setName(resultSet.getString("name"));
                studentObj.setDateOfBirth(resultSet.getString("date_of_birth"));

                studentList.add(studentObj);
            }


        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }

        return studentList;
    }

    @Override
    public Student findById(Integer id) {
        return null;
    }

    @Override
    public void save(Student student) {
        // Dang ky thong tin vao DB.
        try {
            PreparedStatement preparedStatement
                    = BaseRepository.connection.prepareStatement(
                            "insert into student(`name`, date_of_birth)\n" +
                                    "values (?, ?)");
            preparedStatement.setString(1, student.getName());
            preparedStatement.setString(2, student.getDateOfBirth());

            preparedStatement.executeUpdate();

        } catch (SQLException throwables) {
            throwables.printStackTrace();
        }
    }
}
